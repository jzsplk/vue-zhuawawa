<template>
  <div id="app">
<!--     <div class="header">
      <div class="logo">
        <router-link :to="{path: '/'}" ><img class="login-img" src="/static/pic/logo.png" @click="leaveRoom"></router-link>
      </div>
      <div class="login">
        <router-link to="/login"><button>X微信登陆</button></router-link>
        <router-link :to="{ path: '/Tulogin'}" append><button>登陆</button></router-link>
      </div>
    </div> -->
    <router-view/>
    <app-footer></app-footer>
  </div>
</template>

<script>
import MQTT from './MQTT.service.js'
import AppFooter from './components/AppFooter'
export default {
  name: 'App',
  components: {
    'app-footer': AppFooter
  },
  data () {
    return {
      isPlaying: true
    }
  },
  watch: {// 监控路由变化，如果返回主页，执行checklogin,可能这里导致wechat登陆post发送了两次
    '$route' (to, from) {
      if (to.path === '/') {
        this.checkLogin()
      }
    }
  },
  methods: {
    closeZoom () {
      document.addEventListener('touchmove', function (event) {
        if (event.scale) {
          if (event.scale !== 1) {
            event.preventDefault()
          }
        }
      }, { passive: false })
    },
    leaveRoom () {
      MQTT.destoryMQTT()
    },
    checkLogin () {
      let browser = {
        versions: function () {
          let u = navigator.userAgent
          // let app = navigator.appVersion
          return {// 移动终端浏览器版本信息
            trident: u.indexOf('Trident') > -1, // IE内核
            presto: u.indexOf('Presto') > -1, // opera内核
            webKit: u.indexOf('AppleWebKit') > -1, // 苹果、谷歌内核
            gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') === -1, //  火狐内核
            mobile: !!u.match(/AppleWebKit.*Mobile.*/), //  是否为移动终端
            ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), // ios终端
            android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, // android终端或uc浏览器
            iPhone: u.indexOf('iPhone') > -1, //  是否为iPhone或者QQHD浏览器
            iPad: u.indexOf('iPad') > -1, //  是否iPad
            webApp: u.indexOf('Safari') === -1 //  是否web应该程序，没有头部与底部
          }
        },
        language: (navigator.browserLanguage || navigator.language).toLowerCase()
      }
      // 检查是否是微信浏览器
      if (browser.versions().mobile) {
        let ua = navigator.userAgent.toLowerCase()
        if (ua.match(/MicroMessenger/i)) {
          if (ua.match(/MicroMessenger/i)[0] === 'micromessenger') {
            console.log('微信浏览器')
            // 如果不是微信浏览器，游客登陆，检查是否存在session
            if (!this.getCookie('wxzhuawawa')) {
              // 如果没有登陆状态则跳转到登陆页
              console.log('no wx cookie found,will jump to login')
              // 如果是微信浏览器，跳转微信登陆
              this.$router.push('./login')
            } else {
              // this.$router.push('/')
              // 如果有session把用户数据提取到state中
              let data = unescape(this.getCookie('wxzhuawawa'))
              console.log('getCookie parse: ', JSON.parse(data))
              this.$store.dispatch('updataPlayerInfo', JSON.parse(data))
            }
          }
        } else {
          // 如果不是微信浏览器，游客登陆，检查是否存在session
          if (!this.getCookie('zhuawawa')) {
            // 如果没有登陆状态则跳转到登陆页
            console.log('no cookie found')
            this.$router.push('./Tulogin')
          } else {
            // this.$router.push('/')
            // 如果有session把用户数据提取到state中
            let data = unescape(this.getCookie('zhuawawa'))
            console.log('getCookie parse: ', JSON.parse(data))
            this.$store.dispatch('updataPlayerInfo', JSON.parse(data))
          }
        }
      } else {
        // 检查是否存在session
        if (!this.getCookie('zhuawawa')) {
          // 如果没有登陆状态则跳转到登陆页
          console.log('no cookie found')
          this.$router.push('./Tulogin')
        } else {
          // this.$router.push('/')
          // 如果有session把用户数据提取到state中
          let data = unescape(this.getCookie('zhuawawa'))
          console.log('getCookie parse: ', JSON.parse(data))
          this.$store.dispatch('updataPlayerInfo', JSON.parse(data))
        }
      }
    }
  },
  created () {
    // 执行checklogin
    this.checkLogin()
    this.closeZoom()
  }
}
</script>
<style lang="scss" type="text/css">
#app {
  font-family: -apple-system-font,Helvetica Neue,Helvetica,sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  // background-color: black;
  // 解决左右轻微拖动问题
  overflow-x:hidden;
  button {
    border-width: 0;
  }
  img, embed, object, video, canvas {
    max-width: 100%;
  }
  nav a {
    padding: 1.5em;
  }
  nav a, button {
    min-width: 48px;
    outline: none; // 去掉点击时边框
  }
}
.header {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 0;
  background-color: #E9DF38;
  width: 100%;
  height: 100px;
  .logo {
    .login-img {
      width: 90px;
    }
    .login-img:hover {
      background-color: white;
    }
  }
  .login {
    margin-left: 0.5rem;
    button {
      border-style:none;
      padding: 0.5rem;
      background-color: #E9DF38;
      font-size: 0.8rem;
      font-size: 1rem;
    }
    button:hover {
      background-color: #FFF;
    }
  }
}
</style>
